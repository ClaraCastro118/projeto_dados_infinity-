banco_de_dados = []

def adicionar_tarefa():
    nova_tarefa = {
        'nome': input("Digite o nome da tarefa: "),
        'descrição': input("Digite a descrição: "),
        'prioridade': int(input("Digite a prioridade (1-5): ")),
        'categoria': input("Digite a categoria: "),
        'concluído': False
    }
    banco_de_dados.append(nova_tarefa)
    print("Nova tarefa criada com sucesso!")

def listar_tarefas():
    for tarefa in banco_de_dados:
        print(f"Nome: {tarefa["nome"]}")
        print(f"Descrição: {tarefa["descrição"]}")
        print(f"Prioridade: {tarefa["prioridade"]}")
        print(f"Categoria: {tarefa["categoria"]}")
        print(f"Concluído: {"Sim" if tarefa["concluído"] else "Não"}")
        print("----------------------------------")

def listar_por_prioridade():
    prioridade = int(input("Digite a prioridade para ser listada: "))
    for tarefa in banco_de_dados:
        if tarefa["prioridade"] == prioridade:
            print(f"Nome: {tarefa["nome"]}")
            print(f"Descrição: {tarefa["descrição"]}")
            print(f"Prioridade: {tarefa["prioridade"]}")
            print(f"Categoria: {tarefa["categoria"]}")
            print(f"Concluído: {"Sim" if tarefa["concluído"] else "Não"}")
            print("----------------------------------")

def listar_por_categoria():
    categoria = int(input("Digite a categoria para ser listada: "))
    for tarefa in banco_de_dados:
        if tarefa["categoria"] == categoria:
            print(f"Nome: {tarefa["nome"]}")
            print(f"Descrição: {tarefa["descrição"]}")
            print(f"Prioridade: {tarefa["prioridade"]}")
            print(f"Categoria: {tarefa["categoria"]}")
            print(f"Concluído: {"Sim" if tarefa["concluído"] else "Não"}")
            print("----------------------------------")

def concluir_tarefa():
    nome_busca = input("Digite o nome da tarefa a ser concluída: ")
    for tarefa in banco_de_dados:
        if tarefa["nome"] == nome_busca:
            tarefa["concluído"] = True
            print("Tarefa concluída com sucesso!")
            break
    else:
        print("Nenhuma tarefa foi encontrada!")

def remover_tarefa():
    nome_busca = input("Digite o nome da tarefa a ser removida: ")
    for tarefa in banco_de_dados:
        if tarefa["nome"] == nome_busca:
            banco_de_dados.remove(tarefa)
            print("Tarefa foi removida com sucesso!")
            break
    else:
        print("Nenhuma tarefa foi encontrada!")

while True:
    print("1 - Adicionar nova tarefa")
    print("2 - Listar todas as tarefas")
    print("3 - Listar por prioridade")
    print("4 - Listar por categoria")
    print("5 - Marcar tarefa como concluída")
    print("6 - Remover tarefa")
    print("7 - Sair")
    op = int(input("-> "))
    if op == 1:
        adicionar_tarefa()
    elif op == 2:
        listar_tarefas()
    elif op == 3:
        listar_por_prioridade()
    elif op == 4:
        listar_por_categoria()
    elif op == 7:
        break